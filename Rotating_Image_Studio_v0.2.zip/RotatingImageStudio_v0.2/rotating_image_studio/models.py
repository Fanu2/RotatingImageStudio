from dataclasses import dataclass, asdict
from typing import Dict, Any
import uuid

@dataclass
class ImageObject:
    name: str
    path: str
    x: float = 0.0
    y: float = 0.0
    scale: float = 1.0
    rotation: float = 0.0
    opacity: float = 1.0
    visible: bool = True
    z_index: int = 0
    uid: str = ""

    def __post_init__(self):
        if not self.uid:
            self.uid = uuid.uuid4().hex[:10]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]):
        return cls(**data)
