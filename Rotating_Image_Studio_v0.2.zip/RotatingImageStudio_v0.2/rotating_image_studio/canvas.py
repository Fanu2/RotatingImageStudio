from PIL import Image
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QBrush, QColor, QPainter, QPen, QPixmap, QImage
from PySide6.QtWidgets import QGraphicsPixmapItem, QGraphicsScene, QGraphicsView

class ImageItem(QGraphicsPixmapItem):
    selected_changed = Signal(object) if False else None

    def __init__(self, obj, image, parent=None):
        super().__init__(QPixmap.fromImage(self.to_qimage(image)), parent)
        self.obj = obj
        self.setTransformationMode(Qt.TransformationMode.SmoothTransformation)
        self.setFlag(QGraphicsPixmapItem.GraphicsItemFlag.ItemIsMovable, True)
        self.setFlag(QGraphicsPixmapItem.GraphicsItemFlag.ItemIsSelectable, True)
        self.setFlag(QGraphicsPixmapItem.GraphicsItemFlag.ItemSendsGeometryChanges, True)
        self.sync_from_model()

    @staticmethod
    def to_qimage(image):
        rgba = image.convert("RGBA")
        data = rgba.tobytes("raw", "RGBA")
        return QImage(data, rgba.width, rgba.height, QImage.Format.Format_RGBA8888).copy()

    def sync_from_model(self):
        self.setPos(self.obj.x, self.obj.y)
        self.setScale(self.obj.scale)
        self.setRotation(self.obj.rotation)
        self.setOpacity(self.obj.opacity)
        self.setZValue(self.obj.z_index)
        self.setVisible(self.obj.visible)

    def sync_to_model(self):
        p = self.pos()
        self.obj.x = p.x()
        self.obj.y = p.y()
        self.obj.scale = self.scale()
        self.obj.rotation = self.rotation()
        self.obj.opacity = self.opacity()

    def paint(self, painter, option, widget=None):
        super().paint(painter, option, widget)
        if self.isSelected():
            pen = QPen(QColor("#7180ff"), 2, Qt.PenStyle.DashLine)
            painter.setPen(pen)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawRect(self.boundingRect())

class CompositionCanvas(QGraphicsView):
    selection_changed = Signal(object)
    object_moved = Signal(object)

    def __init__(self):
        super().__init__()
        self.scene = QGraphicsScene(self)
        self.setScene(self.scene)
        self.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        self.setBackgroundBrush(QBrush(QColor("#0b0e13")))
        self.setDragMode(QGraphicsView.DragMode.RubberBandDrag)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setSceneRect(-5000, -5000, 10000, 10000)

    def add_image(self, obj, image):
        item = ImageItem(obj, image)
        item.setOffset(-image.width()/2, -image.height()/2)
        self.scene.addItem(item)
        return item

    def selected_item(self):
        items = self.scene.selectedItems()
        return items[0] if items else None

    def mouseReleaseEvent(self, event):
        item = self.selected_item()
        if item:
            item.sync_to_model()
            self.object_moved.emit(item.obj)
        super().mouseReleaseEvent(event)

    def mousePressEvent(self, event):
        super().mousePressEvent(event)
        item = self.selected_item()
        self.selection_changed.emit(item.obj if item else None)

    def wheelEvent(self, event):
        factor = 1.15 if event.angleDelta().y() > 0 else 1/1.15
        self.scale(factor, factor)
