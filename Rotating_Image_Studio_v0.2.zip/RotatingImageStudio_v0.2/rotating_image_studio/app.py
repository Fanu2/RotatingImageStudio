import sys, json
from pathlib import Path
from PIL import Image
from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QKeySequence
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QListWidget, QListWidgetItem, QFileDialog, QFrame, QMessageBox
)
from .models import ImageObject
from .canvas import CompositionCanvas
from .properties import PropertiesPanel

STYLE = """
QMainWindow,QWidget { background:#12151b; color:#e8ecf2; font-family:"Segoe UI","Noto Sans",sans-serif; }
QFrame#panel { background:#191e27; border:1px solid #2a303b; border-radius:10px; }
QLabel#title { font-size:22px; font-weight:700; }
QLabel#muted { color:#8e99aa; }
QPushButton { background:#252c38; border:1px solid #353e4c; border-radius:7px; padding:8px 12px; }
QPushButton:hover { background:#303947; }
QPushButton#primary { background:#5d6cff; border:0; font-weight:700; }
QListWidget { background:#151920; border:1px solid #2a303b; border-radius:8px; }
QListWidget::item { padding:9px; border-radius:6px; }
QListWidget::item:selected { background:#303a63; }
QDoubleSpinBox { background:#151920; border:1px solid #353e4c; border-radius:6px; padding:6px; }
"""

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Rotating Image Studio — v0.2")
        self.resize(1280, 800)
        self.objects = []
        self.build()
        self.make_menu()

    def build(self):
        root = QWidget()
        self.setCentralWidget(root)
        main = QVBoxLayout(root)
        head = QFrame(); head.setObjectName("panel")
        h = QHBoxLayout(head)
        titles = QVBoxLayout()
        t = QLabel("Rotating Image Studio"); t.setObjectName("title")
        s = QLabel("Interactive composition • v0.2"); s.setObjectName("muted")
        titles.addWidget(t); titles.addWidget(s); h.addLayout(titles); h.addStretch()
        self.state = QLabel("● Ready"); self.state.setStyleSheet("color:#8fe3b0")
        h.addWidget(self.state); main.addWidget(head)

        body = QHBoxLayout(); body.setSpacing(12)
        left = QFrame(); left.setObjectName("panel"); ll=QVBoxLayout(left)
        ll.addWidget(QLabel("SCENE / OUTLINER"))
        self.list = QListWidget(); self.list.currentRowChanged.connect(self.select_list); ll.addWidget(self.list,1)
        add = QPushButton("＋ Add Images"); add.clicked.connect(self.add_images); ll.addWidget(add)
        dup = QPushButton("Duplicate Selected"); dup.clicked.connect(self.duplicate); ll.addWidget(dup)
        delete = QPushButton("Delete Selected"); delete.clicked.connect(self.delete); ll.addWidget(delete)
        body.addWidget(left,1)

        center = QFrame(); center.setObjectName("panel"); cl=QVBoxLayout(center)
        self.canvas=CompositionCanvas()
        self.canvas.selection_changed.connect(self.select_object)
        self.canvas.object_moved.connect(self.object_moved)
        cl.addWidget(self.canvas,1)
        bar=QHBoxLayout()
        b=QPushButton("↺ Reset View"); b.clicked.connect(self.reset_view); bar.addWidget(b)
        bar.addWidget(QLabel("Drag images directly on the canvas • Mouse wheel = zoom"))
        bar.addStretch(); cl.addLayout(bar)
        body.addWidget(center,4)

        right=QFrame(); right.setObjectName("panel"); rl=QVBoxLayout(right)
        rl.addWidget(QLabel("PROPERTIES"))
        self.props=PropertiesPanel(); self.props.changed.connect(self.property_changed); rl.addWidget(self.props)
        body.addWidget(right,1)
        main.addLayout(body,1)

    def make_menu(self):
        fm=self.menuBar().addMenu("File")
        for text, fn, shortcut in [
            ("New Project", self.new_project, "Ctrl+N"),
            ("Open Project…", self.open_project, "Ctrl+O"),
            ("Save Project…", self.save_project, "Ctrl+S"),
            ("Add Images…", self.add_images, "Ctrl+I"),
        ]:
            a=QAction(text,self); a.setShortcut(QKeySequence(shortcut)); a.triggered.connect(fn); fm.addAction(a)
        fm.addSeparator(); q=QAction("Quit",self); q.triggered.connect(self.close); fm.addAction(q)

    def add_images(self):
        paths,_=QFileDialog.getOpenFileNames(self,"Add Images","", "Images (*.png *.jpg *.jpeg *.webp *.bmp)")
        for path in paths:
            try:
                img=Image.open(path)
                i=len(self.objects)
                obj=ImageObject(Path(path).stem, path, x=(i%3-1)*230, y=(i//3)*180, z_index=i)
                self.objects.append(obj); self.canvas.add_image(obj,img)
            except Exception as e:
                QMessageBox.warning(self,"Image Error",f"{Path(path).name}: {e}")
        self.refresh(); self.select_row(len(self.objects)-1 if self.objects else -1)

    def refresh(self):
        self.list.blockSignals(True); self.list.clear()
        for obj in self.objects:
            self.list.addItem(QListWidgetItem(f"  {obj.name}"))
        self.list.blockSignals(False)
        self.state.setText(f"● {len(self.objects)} image(s)")

    def select_row(self,row):
        if 0<=row<len(self.objects): self.list.setCurrentRow(row)

    def select_list(self,row):
        if not (0<=row<len(self.objects)):
            self.props.set_object(None); return
        obj=self.objects[row]
        for item in self.canvas.scene.items():
            item.setSelected(getattr(item,"obj",None) is obj)
        self.props.set_object(obj)

    def select_object(self,obj):
        if obj is None:
            self.props.set_object(None); return
        idx=self.objects.index(obj)
        self.list.blockSignals(True); self.list.setCurrentRow(idx); self.list.blockSignals(False)
        self.props.set_object(obj)

    def object_moved(self,obj):
        self.props.set_object(obj)
        self.state.setText(f"● Moved {obj.name}")

    def property_changed(self,name,value):
        obj=self.props.obj
        if not obj: return
        for item in self.canvas.scene.items():
            if getattr(item,"obj",None) is obj:
                item.sync_from_model(); item.update()
                break

    def duplicate(self):
        obj=self.props.obj
        if not obj: return
        new=ImageObject(obj.name+" Copy",obj.path,obj.x+40,obj.y+40,obj.scale,obj.rotation,obj.opacity,obj.visible,len(self.objects))
        self.objects.append(new)
        try: self.canvas.add_image(new,Image.open(new.path))
        except Exception as e: QMessageBox.warning(self,"Error",str(e)); return
        self.refresh(); self.select_row(len(self.objects)-1)

    def delete(self):
        obj=self.props.obj
        if not obj: return
        for item in list(self.canvas.scene.items()):
            if getattr(item,"obj",None) is obj:
                self.canvas.scene.removeItem(item); break
        self.objects.remove(obj); self.refresh(); self.props.set_object(None)

    def new_project(self):
        self.objects.clear(); self.canvas.scene.clear(); self.refresh(); self.props.set_object(None)

    def save_project(self):
        path,_=QFileDialog.getSaveFileName(self,"Save Project","composition.ris","Rotating Image Studio (*.ris)")
        if not path: return
        data={"version":2,"objects":[o.to_dict() for o in self.objects]}
        Path(path).write_text(json.dumps(data,indent=2),encoding="utf-8")
        self.state.setText("● Project saved")

    def open_project(self):
        path,_=QFileDialog.getOpenFileName(self,"Open Project","","Rotating Image Studio (*.ris)")
        if not path: return
        try:
            data=json.loads(Path(path).read_text(encoding="utf-8"))
            self.new_project()
            for d in data.get("objects",[]):
                obj=ImageObject.from_dict(d)
                if not Path(obj.path).exists():
                    continue
                self.objects.append(obj); self.canvas.add_image(obj,Image.open(obj.path))
            self.refresh()
            if self.objects: self.select_row(0)
            self.state.setText("● Project opened")
        except Exception as e:
            QMessageBox.critical(self,"Project Error",str(e))

    def reset_view(self):
        self.canvas.resetTransform()
        self.canvas.centerOn(0,0)

def main():
    app=QApplication(sys.argv); app.setStyleSheet(STYLE)
    win=MainWindow(); win.show(); sys.exit(app.exec())

if __name__=="__main__": main()
