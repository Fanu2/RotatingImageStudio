from PySide6.QtCore import Signal
from PySide6.QtWidgets import QWidget, QVBoxLayout, QGroupBox, QFormLayout, QDoubleSpinBox, QPushButton, QCheckBox

class PropertiesPanel(QWidget):
    changed = Signal(str, float)

    def __init__(self):
        super().__init__()
        self.obj = None
        root = QVBoxLayout(self)
        box = QGroupBox("Transform")
        form = QFormLayout(box)
        self.fields = {}
        specs = [
            ("x", -10000, 10000, 1),
            ("y", -10000, 10000, 1),
            ("scale", 0.01, 20, 0.01),
            ("rotation", -360, 360, 1),
            ("opacity", 0, 1, 0.01),
        ]
        for name, lo, hi, step in specs:
            w = QDoubleSpinBox()
            w.setRange(lo, hi)
            w.setSingleStep(step)
            w.setDecimals(2)
            w.valueChanged.connect(lambda value, n=name: self._changed(n, value))
            self.fields[name] = w
            form.addRow(name.title(), w)
        self.visible = QCheckBox("Visible")
        self.visible.toggled.connect(lambda value: self._changed("visible", 1 if value else 0))
        form.addRow(self.visible)
        root.addWidget(box)

        self.reset_btn = QPushButton("Reset Transform")
        self.reset_btn.clicked.connect(self.reset)
        root.addWidget(self.reset_btn)

        self.center_btn = QPushButton("Center on Canvas")
        self.center_btn.clicked.connect(self.center)
        root.addWidget(self.center_btn)
        root.addStretch()
        self.set_enabled(False)

    def set_enabled(self, value):
        for w in self.fields.values():
            w.setEnabled(value)
        self.visible.setEnabled(value)
        self.reset_btn.setEnabled(value)
        self.center_btn.setEnabled(value)

    def set_object(self, obj):
        self.obj = obj
        self.set_enabled(obj is not None)
        if not obj:
            return
        for n, w in self.fields.items():
            w.blockSignals(True)
            w.setValue(getattr(obj, n))
            w.blockSignals(False)
        self.visible.blockSignals(True)
        self.visible.setChecked(obj.visible)
        self.visible.blockSignals(False)

    def _changed(self, name, value):
        if self.obj is None:
            return
        if name == "visible":
            self.obj.visible = bool(value)
        else:
            setattr(self.obj, name, value)
        self.changed.emit(name, value)

    def reset(self):
        if not self.obj:
            return
        self.obj.x = self.obj.y = 0
        self.obj.scale = 1
        self.obj.rotation = 0
        self.obj.opacity = 1
        self.set_object(self.obj)
        self.changed.emit("reset", 0)

    def center(self):
        if not self.obj:
            return
        self.obj.x = self.obj.y = 0
        self.set_object(self.obj)
        self.changed.emit("center", 0)
