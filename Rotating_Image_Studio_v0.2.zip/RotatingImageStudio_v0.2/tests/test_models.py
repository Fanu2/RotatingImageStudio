from rotating_image_studio.models import ImageObject

def test_image_object_defaults():
    obj = ImageObject("photo", "/tmp/photo.png")
    assert obj.scale == 1.0
    assert obj.opacity == 1.0
    assert obj.visible is True

def test_project_round_trip():
    obj = ImageObject("photo", "/tmp/photo.png", x=10, rotation=25)
    restored = ImageObject.from_dict(obj.to_dict())
    assert restored.name == obj.name
    assert restored.x == 10
    assert restored.rotation == 25
