# Rotating Image Studio v0.2

Interactive PySide6 image-composition studio.

## New in v0.2

- Direct drag-and-drop-style positioning on a graphics canvas
- Select images from canvas or Outliner
- Individual X/Y position
- Scale
- Rotation
- Opacity
- Visibility
- Reset transform
- Center on canvas
- Duplicate and delete
- Project save/load (`.ris`)
- Canvas zoom
- Cleaner separation into model, canvas and properties modules

## Run

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m rotating_image_studio
```

Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python -m rotating_image_studio
```

## Test

```bash
pytest
```
