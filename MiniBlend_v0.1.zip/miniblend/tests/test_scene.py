from miniblend.app import SceneObject

def test_scene_object_defaults():
    obj = SceneObject("Cube.001", "Cube")
    assert obj.x == 0
    assert obj.y == 0
    assert obj.scale == 1.0
