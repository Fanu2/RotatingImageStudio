import sys
from dataclasses import dataclass
from PySide6.QtCore import Qt, QPointF
from PySide6.QtGui import QAction, QBrush, QPen, QPainter, QTransform
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QListWidget,
    QListWidgetItem, QGraphicsView, QGraphicsScene, QGraphicsItem,
    QDoubleSpinBox, QLabel, QPushButton, QGroupBox, QFormLayout, QToolBar,
    QStatusBar, QMessageBox
)


@dataclass
class SceneObject:
    name: str
    kind: str
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    rotation: float = 0.0
    scale: float = 1.0


class ShapeItem(QGraphicsItem):
    def __init__(self, obj: SceneObject):
        super().__init__()
        self.obj = obj
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable, True)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable, True)
        self.setTransformOriginPoint(0, 0)
        self.setPos(obj.x, obj.y)
        self.setRotation(obj.rotation)
        self.setScale(obj.scale)

    def boundingRect(self):
        return (-45, -45, 90, 90)

    def paint(self, painter: QPainter, option, widget=None):
        selected = self.isSelected()
        painter.setPen(QPen(Qt.GlobalColor.yellow if selected else Qt.GlobalColor.white, 2))
        painter.setBrush(QBrush(Qt.GlobalColor.darkGray if self.obj.kind == "Cube"
                                else Qt.GlobalColor.gray))
        if self.obj.kind == "Sphere":
            painter.drawEllipse(-35, -35, 70, 70)
        elif self.obj.kind == "Cylinder":
            painter.drawEllipse(-35, -35, 70, 20)
            painter.drawRect(-35, -25, 70, 50)
            painter.drawEllipse(-35, 15, 70, 20)
        else:
            painter.drawRect(-35, -35, 70, 70)


class Viewport(QGraphicsView):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.scene = QGraphicsScene(self)
        self.setScene(self.scene)
        self.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.setBackgroundBrush(Qt.GlobalColor.black)
        self.setDragMode(QGraphicsView.DragMode.RubberBandDrag)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.zoom = 1.0

    def wheelEvent(self, event):
        factor = 1.15 if event.angleDelta().y() > 0 else 1 / 1.15
        self.zoom *= factor
        self.scale(factor, factor)


class PropertyPanel(QWidget):
    def __init__(self, on_change, parent=None):
        super().__init__(parent)
        self.on_change = on_change
        layout = QVBoxLayout(self)
        box = QGroupBox("Transform")
        form = QFormLayout(box)
        self.fields = {}
        for key in ("x", "y", "z", "rotation", "scale"):
            spin = QDoubleSpinBox()
            spin.setRange(-10000, 10000)
            spin.setDecimals(2)
            spin.setSingleStep(0.1)
            if key == "scale":
                spin.setMinimum(0.01)
                spin.setValue(1.0)
            spin.valueChanged.connect(lambda value, k=key: self.on_change(k, value))
            self.fields[key] = spin
            form.addRow(key.title(), spin)
        layout.addWidget(box)
        layout.addStretch()

    def set_object(self, obj):
        for key, spin in self.fields.items():
            spin.blockSignals(True)
            spin.setValue(getattr(obj, key))
            spin.blockSignals(False)

    def clear(self):
        for spin in self.fields.values():
            spin.blockSignals(True)
            spin.setValue(0 if spin is not self.fields["scale"] else 1)
            spin.blockSignals(False)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("MiniBlend — Blender Feel with PySide6")
        self.resize(1200, 760)
        self.objects = []
        self.counter = 0

        self._make_menu()
        self._make_toolbar()

        central = QWidget()
        root = QHBoxLayout(central)

        left = QVBoxLayout()
        left.addWidget(QLabel("OUTLINER"))
        self.outliner = QListWidget()
        self.outliner.currentRowChanged.connect(self.select_from_outliner)
        left.addWidget(self.outliner)
        for kind in ("Cube", "Sphere", "Cylinder"):
            b = QPushButton(f"+ {kind}")
            b.clicked.connect(lambda checked=False, k=kind: self.add_object(k))
            left.addWidget(b)

        self.viewport = Viewport()

        self.properties = PropertyPanel(self.change_property)

        root.addLayout(left, 1)
        root.addWidget(self.viewport, 4)
        root.addWidget(self.properties, 1)
        self.setCentralWidget(central)

        self.status = QStatusBar()
        self.status.showMessage("Ready — Add an object to begin")
        self.setStatusBar(self.status)

        self.add_object("Cube")

    def _make_menu(self):
        file_menu = self.menuBar().addMenu("File")
        quit_action = QAction("Quit", self)
        quit_action.triggered.connect(self.close)
        file_menu.addAction(quit_action)

        object_menu = self.menuBar().addMenu("Object")
        for label, shortcut, fn in [
            ("Add Cube", "Shift+C", lambda: self.add_object("Cube")),
            ("Add Sphere", "", lambda: self.add_object("Sphere")),
            ("Add Cylinder", "", lambda: self.add_object("Cylinder")),
            ("Duplicate", "Shift+D", self.duplicate),
            ("Delete", "X", self.delete_selected),
        ]:
            a = QAction(label, self)
            if shortcut:
                a.setShortcut(shortcut)
            a.triggered.connect(fn)
            object_menu.addAction(a)

    def _make_toolbar(self):
        bar = QToolBar("Tools")
        self.addToolBar(bar)
        for text, shortcut in [("Select", ""), ("Move (G)", "G"),
                               ("Rotate (R)", "R"), ("Scale (S)", "S"),
                               ("Delete (X)", "X")]:
            a = QAction(text, self)
            if shortcut:
                a.setShortcut(shortcut)
            if shortcut == "X":
                a.triggered.connect(self.delete_selected)
            bar.addAction(a)

    def add_object(self, kind):
        self.counter += 1
        obj = SceneObject(f"{kind}.{self.counter:03d}", kind,
                          x=(self.counter - 1) * 110, y=0)
        self.objects.append(obj)
        item = ShapeItem(obj)
        item.setData(0, obj.name)
        self.viewport.scene.addItem(item)
        self.refresh_outliner()
        self.outliner.setCurrentRow(len(self.objects) - 1)
        self.status.showMessage(f"Added {obj.name}")

    def refresh_outliner(self):
        self.outliner.blockSignals(True)
        self.outliner.clear()
        for obj in self.objects:
            self.outliner.addItem(QListWidgetItem(f"{obj.kind}  {obj.name}"))
        self.outliner.blockSignals(False)

    def current_object(self):
        row = self.outliner.currentRow()
        return self.objects[row] if 0 <= row < len(self.objects) else None

    def select_from_outliner(self, row):
        for item in self.viewport.scene.items():
            item.setSelected(False)
        obj = self.current_object()
        if not obj:
            self.properties.clear()
            return
        for item in self.viewport.scene.items():
            if isinstance(item, ShapeItem) and item.obj is obj:
                item.setSelected(True)
                self.properties.set_object(obj)
                self.status.showMessage(f"Selected {obj.name}")
                break

    def change_property(self, key, value):
        obj = self.current_object()
        if not obj:
            return
        setattr(obj, key, value)
        for item in self.viewport.scene.items():
            if isinstance(item, ShapeItem) and item.obj is obj:
                if key == "x":
                    item.setX(value)
                elif key == "y":
                    item.setY(value)
                elif key == "rotation":
                    item.setRotation(value)
                elif key == "scale":
                    item.setScale(value)
                break

    def duplicate(self):
        obj = self.current_object()
        if not obj:
            return
        self.counter += 1
        copy = SceneObject(f"{obj.kind}.{self.counter:03d}", obj.kind,
                           obj.x + 40, obj.y + 40, obj.z,
                           obj.rotation, obj.scale)
        self.objects.append(copy)
        self.viewport.scene.addItem(ShapeItem(copy))
        self.refresh_outliner()
        self.outliner.setCurrentRow(len(self.objects) - 1)

    def delete_selected(self):
        obj = self.current_object()
        if not obj:
            return
        self.objects.remove(obj)
        for item in list(self.viewport.scene.items()):
            if isinstance(item, ShapeItem) and item.obj is obj:
                self.viewport.scene.removeItem(item)
                item.deleteLater()
        self.refresh_outliner()
        self.properties.clear()
        self.status.showMessage(f"Deleted {obj.name}")


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("MiniBlend")
    win = MainWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
