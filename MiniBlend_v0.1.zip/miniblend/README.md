# MiniBlend v0.1

A small PySide6 application inspired by Blender's workflow.

## Features

- Blender-like Outliner / Viewport / Properties layout
- Add Cube, Sphere and Cylinder
- Select objects
- Transform properties: X/Y/Z, rotation and scale
- Duplicate and delete
- Mouse-wheel viewport zoom
- Keyboard shortcuts: G, R, S, X, Shift+D
- Pytest starter test

## Run

```bash
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows:
.venv\Scripts\activate

pip install -r requirements.txt
python -m miniblend
```

## Run tests

```bash
pytest
```

## Roadmap

v0.2: better viewport manipulation
v0.3: materials and lighting
v0.4: camera
v0.5: simple keyframe animation
v0.6: procedural node playground

This is intentionally not a Blender clone. It is a gentle learning environment for Blender concepts.
