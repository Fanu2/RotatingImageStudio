import sys
import json
from pathlib import Path
from PIL import Image
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QAction, QKeySequence, QFont
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QListWidget, QListWidgetItem, QFileDialog,
    QFrame, QMessageBox, QToolBar, QSplitter
)
from .models import ImageObject, TextObject
from .canvas import CompositionCanvas
from .properties import PropertiesPanel

STYLE = """
QMainWindow,QWidget { background:#11151b; color:#e8edf5; font-family:"Segoe UI","Noto Sans",sans-serif; }
QFrame#panel { background:#191e27; border:1px solid #2b323e; border-radius:10px; }
QLabel#title { font-size:22px; font-weight:700; }
QLabel#muted { color:#8d98aa; }
QPushButton { background:#252c38; border:1px solid #384151; border-radius:7px; padding:8px 11px; }
QPushButton:hover { background:#303948; }
QPushButton#primary { background:#5e6fff; border:0; font-weight:700; }
QListWidget { background:#14181e; border:1px solid #2b323e; border-radius:8px; }
QListWidget::item { padding:8px; border-radius:6px; }
QListWidget::item:selected { background:#303b68; }
QDoubleSpinBox,QSpinBox,QLineEdit,QFontComboBox { background:#14181e; border:1px solid #384151; border-radius:6px; padding:5px; }
QGroupBox { border:1px solid #2b323e; border-radius:8px; margin-top:12px; padding:12px 8px 8px; }
QGroupBox::title { subcontrol-origin:margin; left:10px; padding:0 4px; color:#aab5c5; }
QToolBar { background:#171c24; border:0; padding:6px; spacing:5px; }
"""

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Rotating Image Studio — v0.3")
        self.resize(1400, 860)
        self.objects = []
        self.counter = 0
        self.build_ui()
        self.make_menu()
        self.make_toolbar()
        self.update_ui()

    def build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        main = QVBoxLayout(root)
        header = QFrame(); header.setObjectName("panel")
        h = QHBoxLayout(header)
        box = QVBoxLayout()
        title = QLabel("Rotating Image Studio"); title.setObjectName("title")
        sub = QLabel("Image + Text Composition Studio  •  v0.3"); sub.setObjectName("muted")
        box.addWidget(title); box.addWidget(sub); h.addLayout(box); h.addStretch()
        self.status_label = QLabel("● Ready")
        self.status_label.setStyleSheet("color:#8fe3b0;")
        h.addWidget(self.status_label)
        main.addWidget(header)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setChildrenCollapsible(False)

        left = QFrame(); left.setObjectName("panel")
        ll = QVBoxLayout(left)
        ll.addWidget(QLabel("LAYERS / OUTLINER"))
        self.layer_list = QListWidget()
        self.layer_list.currentRowChanged.connect(self.select_layer)
        ll.addWidget(self.layer_list, 1)

        buttons = QHBoxLayout()
        add_img = QPushButton("＋ Image"); add_img.clicked.connect(self.add_images)
        add_text = QPushButton("T  Text"); add_text.clicked.connect(self.add_text)
        buttons.addWidget(add_img); buttons.addWidget(add_text)
        ll.addLayout(buttons)

        row = QHBoxLayout()
        for label, fn in (
            ("↑", self.bring_forward), ("↓", self.send_backward),
            ("⤒", self.bring_front), ("⤓", self.send_back)
        ):
            b=QPushButton(label); b.setToolTip(fn.__name__.replace("_"," ").title())
            b.clicked.connect(fn); row.addWidget(b)
        ll.addLayout(row)

        row2=QHBoxLayout()
        dup=QPushButton("Duplicate"); dup.clicked.connect(self.duplicate)
        dele=QPushButton("Delete"); dele.clicked.connect(self.delete)
        row2.addWidget(dup); row2.addWidget(dele); ll.addLayout(row2)
        splitter.addWidget(left)

        center = QFrame(); center.setObjectName("panel")
        cl=QVBoxLayout(center)
        self.canvas=CompositionCanvas()
        self.canvas.selection_changed.connect(self.select_object)
        self.canvas.object_changed.connect(self.object_changed)
        cl.addWidget(self.canvas,1)
        hint=QLabel("Drag = move   •   Corner handles = resize   •   Mouse wheel = zoom   •   Double-click text = edit")
        hint.setObjectName("muted"); cl.addWidget(hint)
        splitter.addWidget(center)

        right=QFrame(); right.setObjectName("panel")
        rl=QVBoxLayout(right); rl.addWidget(QLabel("PROPERTIES"))
        self.props=PropertiesPanel()
        self.props.changed.connect(self.property_changed)
        rl.addWidget(self.props,1)
        splitter.addWidget(right)
        splitter.setSizes([250,850,320])
        main.addWidget(splitter,1)

    def make_menu(self):
        file_menu=self.menuBar().addMenu("File")
        for text, fn, key in (
            ("New Project",self.new_project,"Ctrl+N"),
            ("Open Project…",self.open_project,"Ctrl+O"),
            ("Save Project…",self.save_project,"Ctrl+S"),
            ("Add Images…",self.add_images,"Ctrl+I"),
        ):
            a=QAction(text,self); a.setShortcut(QKeySequence(key)); a.triggered.connect(fn); file_menu.addAction(a)
        file_menu.addSeparator()
        q=QAction("Quit",self); q.triggered.connect(self.close); file_menu.addAction(q)

        ins=self.menuBar().addMenu("Insert")
        a=QAction("Image",self); a.triggered.connect(self.add_images); ins.addAction(a)
        a=QAction("Text",self); a.triggered.connect(self.add_text); ins.addAction(a)

        layer=self.menuBar().addMenu("Layer")
        for text,fn in (
            ("Bring Forward",self.bring_forward),("Send Backward",self.send_backward),
            ("Bring to Front",self.bring_front),("Send to Back",self.send_back)
        ):
            a=QAction(text,self); a.triggered.connect(fn); layer.addAction(a)

    def make_toolbar(self):
        tb=QToolBar("Main"); self.addToolBar(tb)
        for text,fn in (
            ("＋ Image",self.add_images),("T Text",self.add_text),
            ("Duplicate",self.duplicate),("Delete",self.delete),
            ("Bring Front",self.bring_front),("Send Back",self.send_back)
        ):
            a=QAction(text,self); a.triggered.connect(fn); tb.addAction(a)

    def add_images(self):
        paths,_=QFileDialog.getOpenFileNames(self,"Add Images","","Images (*.png *.jpg *.jpeg *.webp *.bmp)")
        for path in paths:
            try:
                Image.open(path).verify()
                self.counter+=1
                obj=ImageObject(name=Path(path).stem, path=path,
                    x=((len(self.objects)%3)-1)*230, y=((len(self.objects)//3)%3)*170,
                    z_index=len(self.objects))
                self.objects.append(obj)
                self.canvas.add_item(obj,Image.open(path))
            except Exception as e:
                QMessageBox.warning(self,"Image Error",f"{Path(path).name}: {e}")
        self.rebuild_layers()
        if self.objects: self.select_row(len(self.objects)-1)

    def add_text(self):
        self.counter+=1
        obj=TextObject(name=f"Text {self.counter}", text="Double-click to edit",
                       x=0, y=0, z_index=len(self.objects))
        self.objects.append(obj)
        self.canvas.add_item(obj)
        self.rebuild_layers()
        self.select_row(len(self.objects)-1)

    def rebuild_layers(self):
        # Front-to-back order: highest z first.
        self.objects.sort(key=lambda o:o.z_index, reverse=True)
        self.layer_list.blockSignals(True); self.layer_list.clear()
        for obj in self.objects:
            icon="T" if obj.kind=="text" else "▣"
            self.layer_list.addItem(QListWidgetItem(f"{icon}  {obj.name}"))
        self.layer_list.blockSignals(False)
        self.status_label.setText(f"● {len(self.objects)} layer(s)")

    def select_row(self,row):
        if 0<=row<len(self.objects):
            self.layer_list.setCurrentRow(row)

    def select_layer(self,row):
        if not (0<=row<len(self.objects)):
            self.props.set_object(None); return
        obj=self.objects[row]
        for item in self.canvas.scene.items():
            item.setSelected(getattr(item,"obj",None) is obj)
        self.props.set_object(obj)

    def select_object(self,obj):
        if obj is None:
            self.props.set_object(None); return
        try: row=self.objects.index(obj)
        except ValueError: return
        self.layer_list.blockSignals(True); self.layer_list.setCurrentRow(row); self.layer_list.blockSignals(False)
        self.props.set_object(obj)

    def object_changed(self,obj):
        self.props.set_object(obj)

    def property_changed(self,name,value):
        obj=self.props.obj
        if not obj: return
        if name=="text":
            obj.text=str(value)
        elif hasattr(obj,name):
            setattr(obj,name,value)
        for item in self.canvas.scene.items():
            if getattr(item,"obj",None) is obj:
                if hasattr(item,"apply_model"): item.apply_model()
                elif hasattr(item,"sync_from_model"): item.sync_from_model()
                break
        self.status_label.setText(f"● Editing {obj.name}")

    def current(self):
        return self.props.obj

    def set_z(self, obj, z):
        obj.z_index=z
        for item in self.canvas.scene.items():
            if getattr(item,"obj",None) is obj: item.setZValue(z)

    def normalize_z(self):
        ordered=sorted(self.objects,key=lambda o:o.z_index)
        for i,o in enumerate(ordered): self.set_z(o,i)

    def bring_forward(self):
        obj=self.current()
        if not obj: return
        higher=[o for o in self.objects if o.z_index>obj.z_index]
        if higher:
            other=min(higher,key=lambda o:o.z_index)
            z=other.z_index; self.set_z(other,obj.z_index); self.set_z(obj,z)
        self.rebuild_layers(); self.select_object(obj)

    def send_backward(self):
        obj=self.current()
        if not obj: return
        lower=[o for o in self.objects if o.z_index<obj.z_index]
        if lower:
            other=max(lower,key=lambda o:o.z_index)
            z=other.z_index; self.set_z(other,obj.z_index); self.set_z(obj,z)
        self.rebuild_layers(); self.select_object(obj)

    def bring_front(self):
        obj=self.current()
        if not obj: return
        top=max((o.z_index for o in self.objects),default=0)+1
        self.set_z(obj,top); self.normalize_z()
        self.rebuild_layers(); self.select_object(obj)

    def send_back(self):
        obj=self.current()
        if not obj: return
        low=min((o.z_index for o in self.objects),default=0)-1
        self.set_z(obj,low); self.normalize_z()
        self.rebuild_layers(); self.select_object(obj)

    def duplicate(self):
        obj=self.current()
        if not obj: return
        if obj.kind=="image":
            new=ImageObject(name=obj.name+" Copy",path=obj.path,x=obj.x+40,y=obj.y+40,
                scale=obj.scale,rotation=obj.rotation,opacity=obj.opacity,visible=obj.visible,z_index=max(o.z_index for o in self.objects)+1)
            self.objects.append(new); self.canvas.add_item(new,Image.open(new.path))
        else:
            new=TextObject(name=obj.name+" Copy",text=obj.text,x=obj.x+40,y=obj.y+40,
                scale=obj.scale,rotation=obj.rotation,opacity=obj.opacity,visible=obj.visible,z_index=max(o.z_index for o in self.objects)+1,
                font_family=obj.font_family,font_size=obj.font_size,bold=obj.bold,italic=obj.italic)
            self.objects.append(new); self.canvas.add_item(new)
        self.rebuild_layers(); self.select_object(new)

    def delete(self):
        obj=self.current()
        if not obj: return
        for item in list(self.canvas.scene.items()):
            if getattr(item,"obj",None) is obj:
                self.canvas.scene.removeItem(item); break
        self.objects.remove(obj); self.rebuild_layers(); self.props.set_object(None)

    def new_project(self):
        self.objects.clear(); self.canvas.scene.clear(); self.rebuild_layers(); self.props.set_object(None)

    def save_project(self):
        # Sync current graphics state before serializing.
        self.canvas.sync_selected()
        path,_=QFileDialog.getSaveFileName(self,"Save Project","composition.ris","Rotating Image Studio (*.ris)")
        if not path: return
        data={"version":3,"objects":[o.to_dict() for o in self.objects]}
        Path(path).write_text(json.dumps(data,indent=2),encoding="utf-8")
        self.status_label.setText("● Project saved")

    def open_project(self):
        path,_=QFileDialog.getOpenFileName(self,"Open Project","","Rotating Image Studio (*.ris)")
        if not path: return
        try:
            data=json.loads(Path(path).read_text(encoding="utf-8"))
            self.new_project()
            for d in data.get("objects",[]):
                if d.get("kind")=="image":
                    if not Path(d.get("path","")).exists(): continue
                    obj=ImageObject(**{k:v for k,v in d.items() if k in ImageObject.__dataclass_fields__})
                    self.objects.append(obj); self.canvas.add_item(obj,Image.open(obj.path))
                else:
                    obj=TextObject(**{k:v for k,v in d.items() if k in TextObject.__dataclass_fields__})
                    self.objects.append(obj); self.canvas.add_item(obj)
            self.rebuild_layers()
            if self.objects: self.select_row(0)
            self.status_label.setText("● Project opened")
        except Exception as e:
            QMessageBox.critical(self,"Project Error",str(e))

    def update_ui(self):
        self.canvas.reset_view()
        QTimer.singleShot(100, lambda: self.canvas.centerOn(0,0))

def main():
    app=QApplication(sys.argv)
    app.setApplicationName("Rotating Image Studio")
    app.setStyleSheet(STYLE)
    win=MainWindow(); win.show()
    sys.exit(app.exec())

if __name__=="__main__":
    main()
