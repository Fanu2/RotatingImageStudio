from dataclasses import dataclass, asdict, field
from typing import Any, Dict
import uuid


@dataclass
class SceneObject:
    name: str
    kind: str
    x: float = 0.0
    y: float = 0.0
    scale: float = 1.0
    rotation: float = 0.0
    opacity: float = 1.0
    visible: bool = True
    z_index: int = 0
    uid: str = field(default_factory=lambda: uuid.uuid4().hex[:10])

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ImageObject(SceneObject):
    kind: str = "image"
    path: str = ""


@dataclass
class TextObject(SceneObject):
    kind: str = "text"
    text: str = "Double-click to edit"
    font_family: str = "Segoe UI"
    font_size: int = 48
    bold: bool = False
    italic: bool = False
