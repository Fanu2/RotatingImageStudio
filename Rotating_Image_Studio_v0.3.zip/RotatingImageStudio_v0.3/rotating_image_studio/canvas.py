from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QPainter, QBrush
from PySide6.QtWidgets import QGraphicsScene, QGraphicsView
from .items import ImageItem, TextItem


class CompositionCanvas(QGraphicsView):
    selection_changed = Signal(object)
    object_changed = Signal(object)

    def __init__(self):
        super().__init__()
        self.scene = QGraphicsScene(self)
        self.setScene(self.scene)
        self.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        self.setBackgroundBrush(QBrush(QColor("#0a0d12")))
        self.setSceneRect(-5000, -5000, 10000, 10000)
        self.setTransformationAnchor(
            QGraphicsView.ViewportAnchor.AnchorUnderMouse
        )
        self.setResizeAnchor(
            QGraphicsView.ViewportAnchor.AnchorUnderMouse
        )
        self.setDragMode(QGraphicsView.DragMode.RubberBandDrag)
        self._last_selected = None

    def add_item(self, obj, image=None):
        if obj.kind == "image":
            item = ImageItem(obj, image)
        else:
            item = TextItem(obj)
        self.scene.addItem(item)
        return item

    def selected_item(self):
        items = self.scene.selectedItems()
        return items[0] if items else None

    def sync_selected(self):
        item = self.selected_item()
        if item and hasattr(item, "sync_to_model"):
            item.sync_to_model()
            self.object_changed.emit(item.obj)

    def mousePressEvent(self, event):
        super().mousePressEvent(event)
        item = self.selected_item()
        obj = getattr(item, "obj", None) if item else None
        self.selection_changed.emit(obj)

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        self.sync_selected()

    def wheelEvent(self, event):
        factor = 1.15 if event.angleDelta().y() > 0 else 1 / 1.15
        self.scale(factor, factor)

    def reset_view(self):
        self.resetTransform()
        self.centerOn(0, 0)
