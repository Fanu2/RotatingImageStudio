from PySide6.QtCore import Qt, QPointF, QRectF
from PySide6.QtGui import (
    QBrush, QColor, QFont, QImage, QPainter, QPen, QPixmap
)
from PySide6.QtWidgets import (
    QGraphicsPixmapItem, QGraphicsTextItem, QGraphicsItem
)


HANDLE_SIZE = 12


class TransformMixin:
    """Common interactive transform behavior."""

    def setup_transform_flags(self):
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable, True)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable, True)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemSendsGeometryChanges, True)
        self.setAcceptHoverEvents(True)
        self._resizing = False
        self._resize_start = QPointF()
        self._start_scale = 1.0

    def handle_rect(self):
        r = self.boundingRect()
        return QRectF(
            r.right() - HANDLE_SIZE,
            r.bottom() - HANDLE_SIZE,
            HANDLE_SIZE * 2,
            HANDLE_SIZE * 2,
        )

    def hoverMoveEvent(self, event):
        if self.handle_rect().contains(event.pos()):
            self.setCursor(Qt.CursorShape.SizeFDiagCursor)
        else:
            self.setCursor(Qt.CursorShape.SizeAllCursor)
        super().hoverMoveEvent(event)

    def mousePressEvent(self, event):
        if self.isSelected() and self.handle_rect().contains(event.pos()):
            self._resizing = True
            self._resize_start = event.pos()
            self._start_scale = self.scale()
            event.accept()
            return
        self._resizing = False
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._resizing:
            delta = event.pos() - self._resize_start
            factor = 1.0 + (delta.x() + delta.y()) / 180.0
            factor = max(0.05, factor)
            self.setScale(max(0.05, self._start_scale * factor))
            self.update()
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        self._resizing = False
        super().mouseReleaseEvent(event)

    def paint_selection_handles(self, painter):
        if not self.isSelected():
            return
        r = self.boundingRect()
        painter.setPen(QPen(QColor("#6f7cff"), 2, Qt.PenStyle.DashLine))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRect(r)
        painter.setPen(QPen(QColor("#ffffff"), 1))
        painter.setBrush(QBrush(QColor("#6f7cff")))
        s = HANDLE_SIZE / 2
        for x, y in (
            (r.left(), r.top()),
            (r.right(), r.top()),
            (r.left(), r.bottom()),
            (r.right(), r.bottom()),
        ):
            painter.drawRect(QRectF(x - s, y - s, HANDLE_SIZE, HANDLE_SIZE))


class ImageItem(TransformMixin, QGraphicsPixmapItem):
    def __init__(self, obj, image):
        rgba = image.convert("RGBA")
        data = rgba.tobytes("raw", "RGBA")
        qimage = QImage(
            data, rgba.width, rgba.height, QImage.Format.Format_RGBA8888
        ).copy()
        super().__init__(QPixmap.fromImage(qimage))
        self.obj = obj
        self.setup_transform_flags()
        self.setTransformationMode(Qt.TransformationMode.SmoothTransformation)
        self.setOffset(-rgba.width / 2, -rgba.height / 2)
        self.sync_from_model()

    def sync_from_model(self):
        self.setPos(self.obj.x, self.obj.y)
        self.setScale(self.obj.scale)
        self.setRotation(self.obj.rotation)
        self.setOpacity(self.obj.opacity)
        self.setZValue(self.obj.z_index)
        self.setVisible(self.obj.visible)

    def sync_to_model(self):
        p = self.pos()
        self.obj.x, self.obj.y = p.x(), p.y()
        self.obj.scale = self.scale()
        self.obj.rotation = self.rotation()
        self.obj.opacity = self.opacity()

    def paint(self, painter, option, widget=None):
        super().paint(painter, option, widget)
        self.paint_selection_handles(painter)


class TextItem(TransformMixin, QGraphicsTextItem):
    def __init__(self, obj):
        super().__init__(obj.text)
        self.obj = obj
        self.setup_transform_flags()
        self.setTextInteractionFlags(
            Qt.TextInteractionFlag.NoTextInteraction
        )
        self.apply_model()

    def apply_model(self):
        font = QFont(self.obj.font_family, self.obj.font_size)
        font.setBold(self.obj.bold)
        font.setItalic(self.obj.italic)
        self.setFont(font)
        self.setDefaultTextColor(QColor("#ffffff"))
        self.setPos(self.obj.x, self.obj.y)
        self.setScale(self.obj.scale)
        self.setRotation(self.obj.rotation)
        self.setOpacity(self.obj.opacity)
        self.setZValue(self.obj.z_index)
        self.setVisible(self.obj.visible)
        self.setTextWidth(-1)

    def sync_to_model(self):
        p = self.pos()
        self.obj.x, self.obj.y = p.x(), p.y()
        self.obj.scale = self.scale()
        self.obj.rotation = self.rotation()
        self.obj.opacity = self.opacity()
        self.obj.text = self.toPlainText()

    def mouseDoubleClickEvent(self, event):
        self.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextEditorInteraction
        )
        self.setFocus()
        super().mouseDoubleClickEvent(event)

    def focusOutEvent(self, event):
        self.setTextInteractionFlags(
            Qt.TextInteractionFlag.NoTextInteraction
        )
        self.obj.text = self.toPlainText()
        super().focusOutEvent(event)

    def paint(self, painter, option, widget=None):
        super().paint(painter, option, widget)
        self.paint_selection_handles(painter)
