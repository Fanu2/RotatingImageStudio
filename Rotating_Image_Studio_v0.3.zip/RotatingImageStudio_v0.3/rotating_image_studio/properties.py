from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QGroupBox, QFormLayout, QDoubleSpinBox,
    QSpinBox, QLineEdit, QCheckBox, QPushButton, QFontComboBox
)


class PropertiesPanel(QWidget):
    changed = Signal(str, object)

    def __init__(self):
        super().__init__()
        self.obj = None
        root = QVBoxLayout(self)

        transform = QGroupBox("Transform")
        form = QFormLayout(transform)
        self.x = self.spin(-10000, 10000, 1)
        self.y = self.spin(-10000, 10000, 1)
        self.scale = self.spin(0.05, 20, 0.05)
        self.rotation = self.spin(-360, 360, 1)
        self.opacity = self.spin(0, 1, 0.01)
        for name, w in (
            ("X", self.x), ("Y", self.y), ("Scale", self.scale),
            ("Rotation", self.rotation), ("Opacity", self.opacity)
        ):
            form.addRow(name, w)
        self.visible = QCheckBox("Visible")
        form.addRow(self.visible)
        root.addWidget(transform)

        self.text_box = QGroupBox("Text")
        tf = QFormLayout(self.text_box)
        self.text = QLineEdit()
        self.font = QFontComboBox()
        self.font_size = QSpinBox()
        self.font_size.setRange(6, 300)
        self.bold = QCheckBox("Bold")
        self.italic = QCheckBox("Italic")
        tf.addRow("Content", self.text)
        tf.addRow("Font", self.font)
        tf.addRow("Size", self.font_size)
        tf.addRow(self.bold)
        tf.addRow(self.italic)
        root.addWidget(self.text_box)

        self.reset_btn = QPushButton("↺  Reset Transform")
        self.center_btn = QPushButton("⌖  Center")
        root.addWidget(self.reset_btn)
        root.addWidget(self.center_btn)
        root.addStretch()

        for w, signal_name in (
            (self.x, "x"), (self.y, "y"), (self.scale, "scale"),
            (self.rotation, "rotation"), (self.opacity, "opacity")
        ):
            w.valueChanged.connect(
                lambda value, n=signal_name: self._emit(n, value)
            )
        self.visible.toggled.connect(
            lambda value: self._emit("visible", value)
        )
        self.text.textChanged.connect(
            lambda value: self._emit("text", value)
        )
        self.font.currentFontChanged.connect(
            lambda value: self._emit("font_family", value.family())
        )
        self.font_size.valueChanged.connect(
            lambda value: self._emit("font_size", value)
        )
        self.bold.toggled.connect(lambda value: self._emit("bold", value))
        self.italic.toggled.connect(lambda value: self._emit("italic", value))
        self.reset_btn.clicked.connect(self.reset)
        self.center_btn.clicked.connect(self.center)
        self.set_enabled(False)

    @staticmethod
    def spin(lo, hi, step):
        w = QDoubleSpinBox()
        w.setRange(lo, hi)
        w.setSingleStep(step)
        w.setDecimals(2)
        return w

    def set_enabled(self, enabled):
        for w in (
            self.x, self.y, self.scale, self.rotation, self.opacity,
            self.visible, self.reset_btn, self.center_btn
        ):
            w.setEnabled(enabled)

    def set_object(self, obj):
        self.obj = obj
        self.set_enabled(obj is not None)
        self.text_box.setEnabled(obj is not None and obj.kind == "text")
        if not obj:
            return

        for field, value in (
            (self.x, obj.x), (self.y, obj.y), (self.scale, obj.scale),
            (self.rotation, obj.rotation), (self.opacity, obj.opacity)
        ):
            field.blockSignals(True)
            field.setValue(value)
            field.blockSignals(False)

        self.visible.blockSignals(True)
        self.visible.setChecked(obj.visible)
        self.visible.blockSignals(False)

        is_text = obj.kind == "text"
        if is_text:
            for field, value in (
                (self.text, obj.text),
                (self.font_size, obj.font_size),
                (self.bold, obj.bold),
                (self.italic, obj.italic)
            ):
                field.blockSignals(True)
                field.setValue(value) if hasattr(field, "setValue") else field.setText(value)
                if hasattr(field, "setChecked"):
                    field.setChecked(value)
                field.blockSignals(False)
            self.font.blockSignals(True)
            self.font.setCurrentFont(__import__("PySide6.QtGui", fromlist=["QFont"]).QFont(obj.font_family))
            self.font.blockSignals(False)

    def _emit(self, name, value):
        if self.obj:
            self.changed.emit(name, value)

    def reset(self):
        if not self.obj:
            return
        self.x.setValue(0)
        self.y.setValue(0)
        self.scale.setValue(1)
        self.rotation.setValue(0)
        self.opacity.setValue(1)

    def center(self):
        if self.obj:
            self.x.setValue(0)
            self.y.setValue(0)
