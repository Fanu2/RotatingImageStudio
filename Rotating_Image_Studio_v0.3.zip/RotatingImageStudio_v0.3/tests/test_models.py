from rotating_image_studio.models import ImageObject, TextObject

def test_image_model():
    obj = ImageObject(name="Photo", path="photo.png")
    assert obj.kind == "image"
    assert obj.scale == 1.0

def test_text_model():
    obj = TextObject(name="Title", text="Hello", font_size=72, bold=True)
    assert obj.kind == "text"
    assert obj.text == "Hello"
    assert obj.font_size == 72
    assert obj.bold is True

def test_serialization():
    obj = TextObject(name="Title", text="Hello", x=20, rotation=15)
    data = obj.to_dict()
    assert data["text"] == "Hello"
    assert data["x"] == 20
    assert data["rotation"] == 15
